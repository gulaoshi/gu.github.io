// list.cc 
//
//     	Routines to manage a singly-linked list of "things".
//
// 	A "ListElement2" is allocated for each item to be put on the
//	list; it is de-allocated when the item is removed. This means
//      we don't need to keep a "next" pointer in every object we
//      want to put on a list.
// 
//     	NOTE: Mutual exclusion must be provided by the caller.
//  	If you want a synchronized list, you must use the routines 
//	in synchlist.cc.
//
// Copyright (c) 1992-1993 The Regents of the University of California.
// All rights reserved.  See copyright.h for copyright notice and limitation 
// of liability and disclaimer of warranty provisions.
#ifndef LIST2_CC
#define LIST2_CC

#include "copyright.h"
#include "list2.h"
//----------------------------------------------------------------------
// ListElement2::ListElement2
// 	Initialize a list element, so it can be added somewhere on a list.
//
//	"itemPtr" is the item to be put on the list.  It can be a pointer
//		to anything.
//	"sortKey" is the priority of the item, if any.
//----------------------------------------------------------------------
ListElement2::ListElement2(void *itemPtr, int sortKey)
{
     item = itemPtr;
     key = sortKey;
     next = NULL;	// assume we'll put it at the end of the list 
}
//----------------------------------------------------------------------
// List2::List2
//	Initialize a list, empty to start with.
//	Elements can now be added to the list.
//----------------------------------------------------------------------
List2::List2()
{ 
    first = last = NULL; 
}
//----------------------------------------------------------------------
// List2::~List2
//	Prepare a list for deallocation.  If the list still contains any 
//	ListElements, de-allocate them.  However, note that we do *not*
//	de-allocate the "items" on the list -- this module allocates
//	and de-allocates the ListElements to keep track of each item,
//	but a given item may be on multiple lists, so we can't
//	de-allocate them here.
//----------------------------------------------------------------------
List2::~List2()
{ 
    while (Remove() != NULL)
	;	 // delete all the list elements
}
//----------------------------------------------------------------------
// List2::Append
//      Append an "item" to the end of the list.
//      
//	Allocate a ListElement2 to keep track of the item.
//      If the list is empty, then this will be the only element.
//	Otherwise, put it at the end.
//
//	"item" is the thing to put on the list, it can be a pointer to 
//		anything.
//----------------------------------------------------------------------
void
List2::Append(void *item)
{
    ListElement2 *element = new ListElement2(item, 0);
    if (IsEmpty()) {		// list is empty
	first = element;
	last = element;
    } else {			// else put it after last
	last->next = element;
	last = element;
    }
}
//----------------------------------------------------------------------
// List2::Prepend
//      Put an "item" on the front of the list.
//      
//	Allocate a ListElement2 to keep track of the item.
//      If the list is empty, then this will be the only element.
//	Otherwise, put it at the beginning.
//
//	"item" is the thing to put on the list, it can be a pointer to 
//		anything.
//----------------------------------------------------------------------
void
List2::Prepend(void *item)
{
    ListElement2 *element = new ListElement2(item, 0);
    if (IsEmpty()) {		// list is empty
	first = element;
	last = element;
    } else {			// else put it before first
	element->next = first;
	first = element;
    }
}
//----------------------------------------------------------------------
// List2::Remove
//      Remove the first "item" from the front of the list.
// 
// Returns:
//	Pointer to removed item, NULL if nothing on the list.
//----------------------------------------------------------------------
void *
List2::Remove()
{
    return SortedRemove(NULL);  // Same as SortedRemove, but ignore the key
}
//----------------------------------------------------------------------
// List2::Mapcar
//	Apply a function to each item on the list, by walking through  
//	the list, one element at a time.
//
//	Unlike LISP, this mapcar does not return anything!
//
//	"func" is the procedure to apply to each element of the list.
//----------------------------------------------------------------------
void
List2::Mapcar(VoidFunctionPtr func)
{
    for (ListElement2 *ptr = first; ptr != NULL; ptr = ptr->next) {
       DEBUG('l', "In mapcar, about to invoke %x(%x)\n", func, ptr->item);
       (*func)((int)ptr->item);
    }
}
//----------------------------------------------------------------------
// List2::IsEmpty
//      Returns TRUE if the list is empty (has no items).
//----------------------------------------------------------------------
bool
List2::IsEmpty() 
{ 
    if (first == NULL)
        return TRUE;
    else
	return FALSE; 
}
//----------------------------------------------------------------------
// List2::SortedInsert
//      Insert an "item" into a list, so that the list elements are
//	sorted in increasing order by "sortKey".
//      
//	Allocate a ListElement2 to keep track of the item.
//      If the list is empty, then this will be the only element.
//	Otherwise, walk through the list, one element at a time,
//	to find where the new item should be placed.
//
//	"item" is the thing to put on the list, it can be a pointer to 
//		anything.
//	"sortKey" is the priority of the item.
//----------------------------------------------------------------------
void
List2::SortedInsert(void *item, int sortKey)
{
    ListElement2 *element = new ListElement2(item, sortKey);
    ListElement2 *ptr;		// keep track
    if (IsEmpty()) {	// if list is empty, put
        first = element;
        last = element;
    } else if (sortKey < first->key) {	
		// item goes on front of list
	element->next = first;
	first = element;
    } else {		// look for first elt in list bigger than item
        for (ptr = first; ptr->next != NULL; ptr = ptr->next) {
            if (sortKey < ptr->next->key) {
		element->next = ptr->next;
	        ptr->next = element;
		return;
	    }
	}
	last->next = element;		// item goes at end of list
	last = element;
    }
}
//----------------------------------------------------------------------
// List2::SortedRemove
//      Remove the first "item" from the front of a sorted list.
// 
// Returns:
//	Pointer to removed item, NULL if nothing on the list.
//	Sets *keyPtr to the priority value of the removed item
//	(this is needed by interrupt.cc, for instance).
//
//	"keyPtr" is a pointer to the location in which to store the 
//		priority of the removed item.
//----------------------------------------------------------------------
void *
List2::SortedRemove(int *keyPtr)
{
    ListElement2 *element = first;
    void *thing;
    if (IsEmpty()) 
	return NULL;
    thing = first->item;
    if (first == last) {	// list had one item, now has none 
        first = NULL;
	last = NULL;
    } else {
        first = element->next;
    }
    if (keyPtr != NULL)
        *keyPtr = element->key;
    delete element;
    return thing;
}

#endif
