/////////////////////////////////////////////////////////////////////////
//  Create threads in Nachos
//

//#include "list.h"
#include "list2.h"
#include "system.h"
#include "synch.h"
//#include "testcase.h"
#include <unistd.h>

// Keep busy for some time. Recommend that t values from 1 to 10
// The unit is approximately 0.1 second
// Do NOT modify this function
void busy_for_some_time(int t)
{
	int j;
	int timetask=0;
	for (j = 0 ; j < 10000000 * t ; j ++)
	{
		timetask++;
	}
	currentThread->Yield();
}

Thread *th1;
Thread *th2;

//wait for the busy thread
//DO NOT modify this function except commenting out one line
void wait_for_busy_thread(int arg)
{
	// Store current thread name to var threadname. Do NOT modify.
	char * threadname = currentThread->getName();

	printf("Hello,my name is %s\n", threadname);

	/* Note: Delete or comment out this line to see a different result. */
        th1->Join();

	printf("%s ends\n",threadname);
}


void busy_thread(int arg)
{
	// Store current thread name to var threadname. Do NOT modify.
	char * threadname = currentThread->getName();

	printf ("Hello, my name is %s\n", threadname);

	// Project 1 : add your code here to keep the thread busy for arg units of time.

	printf ("%s ends\n",threadname);
}

void ThreadTestSimple()
{
    printf("Running ThreadTestSimple: starting 2 threads, Thread2 waits for busy Thread1 to finish. \n");
    th1 = new Thread("Thread1");
    th1->Fork(busy_thread, 3);

	//Project 1: add your code here

}


//project1 task4 changes start here
extern List2 * argumentlist;

void vow(int which)
{
	//Project 1: add your code here
}
void con(int which)
{
	//Project 1: add your code here
		
}
//----------------------------------------------------------------------
// ThreadTest
//----------------------------------------------------------------------
void
ThreadTest()
{
    printf("Running ThreadTest: starting 2 threads, One prints out all vows, and the other prints out all cons, in an alternate manner. \n");
    Thread *t1 = new Thread("vow");
    Thread *t2 = new Thread("con");
     
    t1->Fork(vow, 1);
    t2->Fork(con, 2);
}
//project 1 task4 changes end here

